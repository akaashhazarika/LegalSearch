var func = function(){
  axios.get('http://5bc136f784e95e001342c2c9.mockapi.io/search')
  .then(function (response) {
    console.log(response.data[0]['description']);
    var text = "<div>";
    for(var r=0; r<response.data.length; r++){
        text += "<div class=\"card bg-warning mb-3\"><div class=\"card-body\" style=\"te\"><a href='" + response.data[r]['url'] + "'>" + response.data[r]['url'] + "</a>"+ "<br>" + response.data[r]['description'] +"</li></div></div><br>";
    }
    text += "</div>";
    console.log(response);
    document.getElementById("solution").innerHTML = text;
 })
  .catch(function (error) {
  });
    //dLen = data.length;
}
